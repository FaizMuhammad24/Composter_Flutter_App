import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../../models/reward_model.dart';
import '../notifications/user_notification_service.dart';
import '../user/points_service.dart';

class RewardService {
  static final CollectionReference _rewardsCol = 
      FirebaseFirestore.instance.collection('rewards');
  static final CollectionReference _claimsCol = 
      FirebaseFirestore.instance.collection('reward_claims');

  /// Ambil semua reward yang aktif
  static Future<List<RewardModel>> getAllRewards() async {
    try {
      final snap = await _rewardsCol
          .where('isActive', isEqualTo: true)
          .orderBy('points', descending: false)
          .get();
      return snap.docs
          .map((doc) => RewardModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('Error mengambil rewards: $e');
      return [];
    }
  }

  /// Ambil beberapa reward terpopuler untuk halaman depan
  static Future<List<RewardModel>> getPopularRewards({int limit = 4}) async {
    try {
      final snap = await _rewardsCol
          .where('isActive', isEqualTo: true)
          .orderBy('points', descending: false)
          .limit(limit)
          .get();
      return snap.docs
          .map((doc) => RewardModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('Error mengambil popular rewards: $e');
      return [];
    }
  }

  /// Buat klaim reward baru (tanpa potong poin — SA yang approve)
  static Future<String> createClaim({
    required String userEmail,
    required String userName,
    required String rewardId,
    required String rewardName,
    required int quantity,
    required int totalPoints,
  }) async {
    final id = _claimsCol.doc().id;
    await _claimsCol.doc(id).set({
      'id': id,
      'userEmail': userEmail,
      'userName': userName,
      'rewardId': rewardId,
      'rewardName': rewardName,
      'quantity': quantity,
      'totalPoints': totalPoints,
      'status': 'pending',
      'createdAt': DateTime.now().toIso8601String(),
    });
    return id;
  }

  /// Ambil semua klaim pending (untuk SuperAdmin)
  static Future<List<Map<String, dynamic>>> getPendingClaims() async {
    try {
      final snap = await _claimsCol
          .where('status', isEqualTo: 'pending')
          .get();
      final docs = snap.docs
          .map((doc) => doc.data() as Map<String, dynamic>)
          .toList();
      docs.sort((a, b) => (b['createdAt'] as String).compareTo(a['createdAt'] as String));
      return docs;
    } catch (e) {
      debugPrint('Error mengambil pending claims: $e');
      return [];
    }
  }

  /// Approve klaim (SuperAdmin) — potong poin user
  static Future<void> approveClaim(String claimId) async {
    await _claimsCol.doc(claimId).update({
      'status': 'approved',
      'processedAt': DateTime.now().toIso8601String(),
    });
  }

  /// Reject klaim (SuperAdmin) — tidak perlu potong poin karena belum dipotong
  static Future<void> rejectClaim(String claimId) async {
    await _claimsCol.doc(claimId).update({
      'status': 'rejected',
      'processedAt': DateTime.now().toIso8601String(),
    });
  }

  /// Ambil riwayat klaim user tertentu
  static Stream<List<Map<String, dynamic>>> getUserClaimsStream(String userEmail) {
    return _claimsCol
        .where('userEmail', isEqualTo: userEmail)
        .snapshots()
        .map((snap) {
          final docs = snap.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();
          docs.sort((a, b) => (b['createdAt'] as String).compareTo(a['createdAt'] as String));
          return docs;
        });
  }

  /// Ambil riwayat klaim user tertentu (Future)
  static Future<List<Map<String, dynamic>>> getUserClaims(String userEmail) async {
    try {
      final snap = await _claimsCol
          .where('userEmail', isEqualTo: userEmail)
          .get();
      final docs = snap.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();
      docs.sort((a, b) => (b['createdAt'] as String).compareTo(a['createdAt'] as String));
      return docs;
    } catch (e) {
      debugPrint('Error getUserClaims: $e');
      return [];
    }
  }

  /// Klaim reward oleh User (dengan anti-spam)
  static Future<bool> claimReward({
    required String userEmail,
    required String rewardId,
    required int rewardPoints,
    required String rewardName,
  }) async {
    try {
      // Cek apakah ada klaim pending
      final pendingSnap = await _claimsCol
          .where('userEmail', isEqualTo: userEmail)
          .where('status', isEqualTo: 'pending')
          .get();

      if (pendingSnap.docs.isNotEmpty) {
        throw Exception('Anda masih memiliki klaim hadiah yang sedang diproses.');
      }

      // Ambil info user untuk nama lengkap
      final userSnap = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: userEmail)
          .limit(1)
          .get();
      final userName = userSnap.docs.isNotEmpty
          ? (userSnap.docs.first.data()['name'] as String? ?? userEmail)
          : userEmail;

      await createClaim(
        userEmail: userEmail,
        userName: userName,
        rewardId: rewardId,
        rewardName: rewardName,
        quantity: 1,
        totalPoints: rewardPoints,
      );

      // Kurangi poin otomatis saat klaim dibuat
      await PointsService.deductUserPoints(
        userEmail: userEmail,
        pointsToDeduct: rewardPoints,
      );

      return true;
    } catch (e) {
      debugPrint('Error claiming reward: $e');
      if (e is Exception) rethrow;
      return false;
    }
  }

  static Future<void> createReward({
    required String name,
    required String description,
    required String category,
    required int points,
    required String imageUrl,
  }) async {
    final id = _rewardsCol.doc().id;
    final reward = RewardModel(
      id: id,
      name: name,
      description: description,
      category: category,
      points: points,
      imageUrl: imageUrl,
      createdAt: DateTime.now(),
    );
    await _rewardsCol.doc(id).set(reward.toJson());
    // Trigger Push Notification to all users
    await UserNotificationService.broadcastAnnouncement(
      'Hadiah Baru Telah Tersedia! 🎁',
      'Segera tukarkan $points poinmu dengan $name sekarang juga sebelum kehabisan!',
    );
  }

  static Future<void> updateReward(RewardModel reward) async {
    await _rewardsCol.doc(reward.id).update(reward.toJson());
  }

  static Future<void> deleteReward(String id) async {
    await _rewardsCol.doc(id).delete();
  }

  static Future<int> getTotalRewards() async {
    final snap = await _rewardsCol.count().get();
    return snap.count ?? 0;
  }

  static Future<int> getTotalPointsValue() async {
    final snap = await _rewardsCol.get();
    int total = 0;
    for (var doc in snap.docs) {
      final data = doc.data() as Map<String, dynamic>?;
      if (data != null && data.containsKey('points')) {
        total += (data['points'] as num).toInt();
      }
    }
    return total;
  }

  static List<String> getCategories() {
    return ['Voucher', 'Produk', 'Merchandise'];
  }
}
